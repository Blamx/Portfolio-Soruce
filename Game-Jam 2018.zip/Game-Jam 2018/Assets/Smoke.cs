﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Smoke : MonoBehaviour {

    public GameObject player;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(GameState.gameState == 1)
        {
            transform.position = new Vector3(1000, 1000, 1000);
        }
        transform.position = player.transform.position;

        if (player.GetComponent<PlayerStats>().health >= player.GetComponent<PlayerStats>().maxHealth * 0.9)
        {
            var emission = gameObject.GetComponent<ParticleSystem>().emission;
            emission.rateOverTime = 100 - ((player.GetComponent<PlayerStats>().health / player.GetComponent<PlayerStats>().maxHealth) * 100);
        }
//            Debug.Log(100 -  (player.GetComponent<PlayerStats>().health / player.GetComponent<PlayerStats>().maxHealth) * 100);

    }
}
