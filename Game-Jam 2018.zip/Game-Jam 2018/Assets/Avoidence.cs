﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Avoidence : MonoBehaviour {

    public bool collision = false;
    public Vector3 colPos;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.name != "Player" || other.name != "Player Cannon Ball" || other.name != "Enemy Cannon Ball")
        {
            collision = true;
            colPos = other.transform.position;
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.name != "Player" || other.name != "Player Cannon Ball" || other.name != "Enemy Cannon Ball")
        {
            collision = true;
            colPos = other.transform.position;
        }
    }
   
}
