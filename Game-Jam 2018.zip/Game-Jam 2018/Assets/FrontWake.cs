﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrontWake : MonoBehaviour
{
    public GameObject player;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        var emission = gameObject.GetComponent<ParticleSystem>().emission;
        if (player.GetComponent<PlayerController>().shipDirection <= 0f)
        {
            emission.rateOverTime = 0f;
        }
        else
        {
            emission.rateOverTime = player.GetComponent<PlayerController>().shipDirection;
        }
    }

}
