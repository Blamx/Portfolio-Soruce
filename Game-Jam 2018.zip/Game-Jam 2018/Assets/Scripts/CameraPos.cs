﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraPos : MonoBehaviour {

    public GameObject Player;
	public float camLookAheadVal = 50.0f;

    public Vector3 CameraPosition;

	void Start ()
    {
        CameraPosition = new Vector3(0,0,0);
	}
	
	void Update ()
    {
		if (GameState.gameState == 0)
		{
            Vector3 newPos = Player.transform.position;
			newPos.z = -10;

			transform.position = Vector3.Lerp(new Vector3(transform.position.x, transform.position.y, -10), newPos, 0.07f);
		}

        CameraPosition = transform.position;
	}
}

