﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterStats : MonoBehaviour {

    public int slotX, slotY;

    public bool isIsland;

    public GameObject island;

    public GameObject bridgeDown , bridgeRight;

    bool menu;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		if(GameState.gameState == 1 && !menu)
        {
            menu = true;
            if(island != null)
                island.SetActive(false);
            if (bridgeDown != null)
                bridgeDown.SetActive(false);
            if (bridgeRight != null)
                bridgeRight.SetActive(false);
        }
        else if(GameState.gameState == 0 && menu)
        {
            menu = false;
            if (island != null)
                island.SetActive(true);
            if (bridgeDown != null)
                bridgeDown.SetActive(true);
            if (bridgeRight != null)
                bridgeRight.SetActive(true);
        }
	}
}
