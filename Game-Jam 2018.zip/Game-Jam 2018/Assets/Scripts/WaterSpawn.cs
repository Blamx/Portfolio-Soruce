﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class WaterSpawn : MonoBehaviour {

    public GameObject Player;
    public GameObject waterPrefab;
    public GameObject waterHolder;

    float Displacement = 10;

    //how many slots around the player
    public int range = 2;

    bool TileChange;

    public GameObject island;
    public GameObject bridgeDown;
    public GameObject bridgeRight;

    //debug
    public Text debugTile;

    public List<GameObject> waterTiles = new List<GameObject>();


    int arrOffset = 500;
    bool[,] slots = new bool[1000,1000];

    public int playerSlotX, playerSlotY;

    // Use this for initialization
    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (GameState.gameState == 0)
        {
            float basePosX, basePosY;
            basePosX = Player.transform.position.x;
            basePosY = Player.transform.position.y;

            playerSlotX = Mathf.RoundToInt(basePosX / 10);
            playerSlotY = Mathf.RoundToInt(basePosY / 10);

            debugTile.GetComponent<Text>().text = playerSlotX + ", " + playerSlotY;
            //x
            for (int i = -range; i < range; i++)
            {
                //y
                for (int j = -range; j < range; j++)
                {
                    SpawnTile(playerSlotX + i, playerSlotY + j);
                }
            }

            checkTiles();

            if (TileChange)
            {
                RemoveTile(playerSlotX, playerSlotY);
            }
        }
    }

    void SpawnTile(int x, int y)
    {
        if (!slots[x + arrOffset, y + arrOffset])
        {
            TileChange = true;
            slots[x + arrOffset, y + arrOffset] = true;
            GameObject temp;
            temp = Instantiate<GameObject>(waterPrefab, waterHolder.transform);
            temp.transform.position = new Vector3(x * Displacement, y * Displacement, 10);
            temp.GetComponent<WaterStats>().slotX = x;
            temp.GetComponent<WaterStats>().slotY = y;

             int t = (int)Random.Range(0, 10);

            
          
            if(t == 1 && (x != 0 && y != 0))
            {
                temp.GetComponent<WaterStats>().isIsland = true;
                temp.GetComponent<WaterStats>().island = Instantiate<GameObject>(island);

                temp.GetComponent<WaterStats>().island.transform.position = new Vector3(temp.transform.position.x, temp.transform.position.y, temp.transform.position.z);
            }
            waterTiles.Add(temp);            
        }
        else
        {
            //Debug.Log("[Spawn Function]: Tile all ready exists");
        }
    }

    void checkTiles()
    {


        for (int i = 0; i < waterTiles.Count; i++)
        {
            if (waterTiles[i].GetComponent<WaterStats>().isIsland)
            {
                for (int j = 0; j < waterTiles.Count; j++)
                {

                    if (waterTiles[j].GetComponent<WaterStats>().isIsland)
                    {
                        if (waterTiles[i].GetComponent<WaterStats>().slotX - waterTiles[j].GetComponent<WaterStats>().slotX == 0)
                        {
                            if (waterTiles[i].GetComponent<WaterStats>().slotY - waterTiles[j].GetComponent<WaterStats>().slotY == -1)
                            {
                                if (waterTiles[j].GetComponent<WaterStats>().bridgeDown)
                                {
                                    Destroy(waterTiles[j].GetComponent<WaterStats>().bridgeDown);
                                }
                                waterTiles[j].GetComponent<WaterStats>().bridgeDown = Instantiate<GameObject>(bridgeDown);
                                waterTiles[j].GetComponent<WaterStats>().bridgeDown.transform.position = waterTiles[j].transform.position + new Vector3(0, -5, -2);
                            }
                        }
                        if (waterTiles[i].GetComponent<WaterStats>().slotX - waterTiles[j].GetComponent<WaterStats>().slotX == -1)
                        {
                            if (waterTiles[i].GetComponent<WaterStats>().slotY - waterTiles[j].GetComponent<WaterStats>().slotY == 0)
                            {
                                if (waterTiles[j].GetComponent<WaterStats>().bridgeRight)
                                {
                                    Destroy(waterTiles[j].GetComponent<WaterStats>().bridgeRight);
                                }
                                waterTiles[j].GetComponent<WaterStats>().bridgeRight = Instantiate<GameObject>(bridgeRight);
                                waterTiles[j].GetComponent<WaterStats>().bridgeRight.transform.position = waterTiles[j].transform.position + new Vector3(-5, 0, -2);
                            }
                        }
                    }
                }
            }
        }
    }
    void RemoveTile(int x, int y)
    {
        for (int i = 0; i < waterTiles.Count; i++)
        {
            if(waterTiles[i].GetComponent<WaterStats>().slotX > x + range)
            {
                if(waterTiles[i].GetComponent<WaterStats>().isIsland)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().island);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeDown != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeDown);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeRight != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeRight);
                }
                slots[waterTiles[i].GetComponent<WaterStats>().slotX + arrOffset, waterTiles[i].GetComponent<WaterStats>().slotY + arrOffset] = false;
                Destroy(waterTiles[i].gameObject);
                waterTiles.RemoveAt(i);
                Debug.Log(x + " , " + y + " Removed");
            }
            else if (waterTiles[i].GetComponent<WaterStats>().slotX < x - range)
            {
                if (waterTiles[i].GetComponent<WaterStats>().isIsland)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().island);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeDown != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeDown);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeRight != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeRight);
                }
                slots[waterTiles[i].GetComponent<WaterStats>().slotX + arrOffset, waterTiles[i].GetComponent<WaterStats>().slotY + arrOffset] = false;
                Destroy(waterTiles[i].gameObject);
                waterTiles.RemoveAt(i);
                Debug.Log(x + " , " + y + " Removed");
            }
            else if (waterTiles[i].GetComponent<WaterStats>().slotY > y + range)
            {
                if (waterTiles[i].GetComponent<WaterStats>().isIsland)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().island);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeDown != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeDown);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeRight != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeRight);
                }

                slots[waterTiles[i].GetComponent<WaterStats>().slotX + arrOffset, waterTiles[i].GetComponent<WaterStats>().slotY + arrOffset] = false;
                Destroy(waterTiles[i].gameObject);
                waterTiles.RemoveAt(i);
                Debug.Log(x + " , " + y + " Removed");
            }
            else if (waterTiles[i].GetComponent<WaterStats>().slotY < y - range)
            {
                if (waterTiles[i].GetComponent<WaterStats>().isIsland)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().island);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeDown != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeDown);
                }
                if (waterTiles[i].GetComponent<WaterStats>().bridgeRight != null)
                {
                    Destroy(waterTiles[i].GetComponent<WaterStats>().bridgeRight);
                }
                slots[waterTiles[i].GetComponent<WaterStats>().slotX + arrOffset, waterTiles[i].GetComponent<WaterStats>().slotY + arrOffset] = false;
                Destroy(waterTiles[i].gameObject);
                waterTiles.RemoveAt(i);
                //Debug.Log(x + " , " + y + " Removed");
            }
        }
        

        
    }
}
