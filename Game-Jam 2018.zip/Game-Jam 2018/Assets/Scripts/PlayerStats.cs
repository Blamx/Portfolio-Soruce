﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour {

    public float 
		health, 
		maxHealth, 
		damage, 
		fireRate, 
		CannonNumber,
		
		speed, 
		maxSpeed, 
		backSpeed, 
		accel, 
		angle, 
		turnSpeed;

    public bool isPlayer;

    public bool dead;


    public Sprite damagedPlayer;
    public Sprite repairedPlayer;

    float timer = 0;
    // Use this for initialization
    void Start ()
    {

	}
	
	// Update is called once per frame
	void Update ()
    {
        timer -= Time.deltaTime;
		if(health <= 0 && !isPlayer)
        {
           if(gameObject.GetComponent<SmallEnemyShip>())
            {
                gameObject.GetComponent<SmallEnemyShip>().destroySmallShip(true);
            }
           else if(gameObject.GetComponent<MediumEnemyShip>())
            {
                gameObject.GetComponent<MediumEnemyShip>().destroyMediumShip();
            }
            else if (gameObject.GetComponent<LargeEnemyShip>())
            {
                gameObject.GetComponent<LargeEnemyShip>().destroyLargeShip();
            }

        }
        else if (health <= 0 && isPlayer)
        {
            dead = true;
            gameObject.SetActive(false);
        }
        if (health <= maxHealth/2)
        {
            gameObject.GetComponent<SpriteRenderer>().sprite = damagedPlayer;
        }
        else
        {
            gameObject.GetComponent<SpriteRenderer>().sprite = repairedPlayer;
        }

        if (isPlayer)
        {
            GetComponent<PlayerController>().shipMaxSpeed = maxSpeed;
            GetComponent<PlayerController>().shipTurnSpeed = turnSpeed;

			if (timer < 0 && (GetComponent<PlayerController>().lTimer <= 0.0f) && (GetComponent<PlayerController>().rTimer <= 0.0f))
            {
                timer = 0.5f;
                health += 5 * (maxHealth / 100f);
                if(health > maxHealth)
                {
                    health = maxHealth;
                }
            }
        }

    }
}
