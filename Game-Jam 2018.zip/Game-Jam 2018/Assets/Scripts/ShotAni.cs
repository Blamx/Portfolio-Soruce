﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotAni : MonoBehaviour {

	// Use this for initialization
	void Start ()
    {
        Destroy(gameObject, 0.65f/2);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
