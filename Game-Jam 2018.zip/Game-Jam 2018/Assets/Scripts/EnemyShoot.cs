﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShoot : MonoBehaviour
{

    public GameObject[] cannonBall = new GameObject[1];
    float timer = 0;

	public int numCannons = 4;
	int lCannon = 0;
	int rCannon = 0;

	GameObject[] cannons = new GameObject[8];

    // Use this for initialization
    void Start()
    {
		cannons[0] = GameObject.Find("Enemy Left Cannon 1");
		cannons[1] = GameObject.Find("Enemy Left Cannon 3");
		cannons[2] = GameObject.Find("Enemy Left Cannon 2");
		cannons[3] = GameObject.Find("Enemy Left Cannon 4");
		cannons[4] = GameObject.Find("Enemy Right Cannon 1");
		cannons[5] = GameObject.Find("Enemy Right Cannon 3");
		cannons[6] = GameObject.Find("Enemy Right Cannon 2");
		cannons[7] = GameObject.Find("Enemy Right Cannon 4");
	}

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;

        if (timer < 0)
        {
            if (gameObject.GetComponent<MediumEnemyShip>())
            {
                if (gameObject.GetComponent<MediumEnemyShip>().shootRight && gameObject.GetComponent<MediumEnemyShip>().shooting)
                {
                    GameObject gob = cannonBall[0];
                    gob.transform.position = transform.position + new Vector3(0, 0, 1);
                    gob.GetComponent<CannonBall>().dir = transform.right;
                    gob.GetComponent<CannonBall>().cannonBallDamage = gameObject.GetComponent<PlayerStats>().damage;
                    Instantiate(gob);
                    timer = gameObject.GetComponent<PlayerStats>().fireRate;
                }
                else if (gameObject.GetComponent<MediumEnemyShip>().shooting)
                {
                    GameObject gob = cannonBall[0];
                    gob.transform.position = transform.position + new Vector3(0, 0, 1);
                    gob.GetComponent<CannonBall>().dir = -transform.right;
                    gob.GetComponent<CannonBall>().cannonBallDamage = gameObject.GetComponent<PlayerStats>().damage;
                    Instantiate(gob);
                    timer = gameObject.GetComponent<PlayerStats>().fireRate;
                }
            }
            else if (gameObject.GetComponent<LargeEnemyShip>())
            {
                if (!gameObject.GetComponent<LargeEnemyShip>().shootRight && gameObject.GetComponent<LargeEnemyShip>().shooting)
                {
					Debug.Log("Shooting left 2");
					GameObject gob = cannonBall[0];

					lCannon += 1;
					lCannon = lCannon % numCannons;
					gob.transform.position = cannons[lCannon].transform.position;
					gob.GetComponent<CannonBall>().dir = -transform.right;
					gob.GetComponent<CannonBall>().cannonBallDamage = gameObject.GetComponent<PlayerStats>().damage;

					Instantiate(gob);
					timer = gameObject.GetComponent<PlayerStats>().fireRate;
				}
                else if (gameObject.GetComponent<LargeEnemyShip>().shootRight && gameObject.GetComponent<LargeEnemyShip>().shooting)
                {
					Debug.Log("Shooting right 2");
					GameObject gob = cannonBall[0];

					rCannon += 1;
					rCannon = rCannon % numCannons;
					gob.transform.position = cannons[rCannon + 4].transform.position;
					gob.GetComponent<CannonBall>().dir = transform.right;
					gob.GetComponent<CannonBall>().cannonBallDamage = gameObject.GetComponent<PlayerStats>().damage;

					Instantiate(gob);
                    timer = gameObject.GetComponent<PlayerStats>().fireRate;
                }
            }
        }
    }
}
