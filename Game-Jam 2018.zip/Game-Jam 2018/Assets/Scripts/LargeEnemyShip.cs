﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class LargeEnemyShip : MonoBehaviour
{
    const float TAU = 6.2831853071f;

    public float shipMaxSpeed = 0.04f;
    public float shipMaxBackwardSpeed = -0.3f;
    public float shipSpeed = 0.0f;//-1 <-> 1
    public float shipAccel = 0.3f; //time to max in seconds

    public float shipAngle = 0.0f; //radians
    public float shipTurnSpeed = 0.12f; //rotations per second

    float orbitDistanceFar = 28.0f;

    public GameObject steerTarget;
    public GameObject manager;

    public bool shootRight = true;
    public bool shooting = false;

    public GameObject indicatorPrefab;
    GameObject indicator;

    void Start()
    {
        indicator = Instantiate(indicatorPrefab);
        manager = GameObject.Find("GameManager");
        steerTarget = GameObject.Find("Player");
        transform.position = new Vector3(transform.position.x, transform.position.y, 0.0f); //set start z to 0 so all same level
    }

    void Update()
    {
        if (steerTarget != null)
        {//Ship Steer / left & right---------------------------------------------------------------------------------------------------------------------
            Vector3 objectRelativePos = transform.InverseTransformPoint(steerTarget.transform.position);
            float disBetweenObj = Vector3.Magnitude(transform.position - steerTarget.transform.position);
            float angleBetweenForwards = Vector3.Angle(transform.up, transform.position - steerTarget.transform.position);


            if (disBetweenObj < orbitDistanceFar)
            {
                if (objectRelativePos.x < 0.0f && angleBetweenForwards < 90.0f)
                {
                    shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;

                }
                else if (objectRelativePos.x > 0.0f && angleBetweenForwards < 90.0f)
                {
                    shipAngle += shipTurnSpeed * TAU * Time.deltaTime;

                }
                else if (objectRelativePos.x < 0.0f && angleBetweenForwards > 90.0f)
                {
                    shipAngle += shipTurnSpeed * TAU * Time.deltaTime;

                }
                else if (objectRelativePos.x > 0.0f && angleBetweenForwards > 90.0f)
                {
                    shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                }

                //Shooting behavior
                float aimCone = 10.0f;
                if (objectRelativePos.x > 0.0f && (angleBetweenForwards > (90.0f - aimCone) && angleBetweenForwards < (90.0f + aimCone))) //right
                {
                    Debug.Log("Shooting right 1");
                    shooting = true;
                    shootRight = true;
                }
                else if (objectRelativePos.x < 0.0f && (angleBetweenForwards > (90.0f - aimCone) && angleBetweenForwards < (90.0f + aimCone))) //left
                {
                    Debug.Log("Shooting left 1");
                    shooting = true;
                    shootRight = false;
                }
                else
                {
                    shooting = false;
                }

            }
            else
            {
                if (objectRelativePos.x < 0.0f) //right
                {
                    shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                }
                else if (objectRelativePos.x > 0.0f) //left
                {
                    shipAngle += shipTurnSpeed * TAU * Time.deltaTime;
                }
            }



            //Ship Speed / forward & backward----------------------------------------------------------------------------------------------------------------
            Debug.DrawRay(transform.position, transform.up * 1.2f, Color.red);
            angleBetweenForwards = 1.0f - (angleBetweenForwards / 180.0f);

            float turnVarFull = 0.6f;
            float turnVarStop = 0.7f;

            float shipTargetSpeed = 0.0f;

            if (angleBetweenForwards >= turnVarStop)
            {
                shipTargetSpeed = 0.0f;
            }
            else if (angleBetweenForwards < turnVarStop && angleBetweenForwards > turnVarFull)
            {
                float lerpAmmt = (angleBetweenForwards - turnVarFull) / (turnVarStop - turnVarFull);
                shipTargetSpeed = Mathf.Lerp(1, 0, lerpAmmt);
            }
            else if (angleBetweenForwards <= turnVarFull)
            {
                shipTargetSpeed = 1.0f;
            }

            if (shipSpeed > shipTargetSpeed)
            {
                shipSpeed -= shipAccel * Time.deltaTime;
            }
            else if (shipSpeed < shipTargetSpeed)
            {
                shipSpeed += shipAccel * Time.deltaTime;
            }

            //-------------------------
            if (shipSpeed > 1.0f)
            {
                shipSpeed = 1.0f;
            }
            if (shipSpeed < shipMaxBackwardSpeed)
            {
                shipSpeed = shipMaxBackwardSpeed;
            }

            //Update position & rotation-------------------------------------------------------------------------------------------------------------------------
            transform.position += new Vector3(
                shipSpeed * shipMaxSpeed * Mathf.Sin(shipAngle),
                shipSpeed * shipMaxSpeed * Mathf.Cos(shipAngle),
                0);
            transform.rotation = Quaternion.Euler(
                0,
                0,
                -shipAngle * (360.0f / TAU));
        }

        float ssY = 27f;
        float ssX = 44f;

        //Indicator
        Vector3 temp = GameObject.Find("Player Camera").GetComponent<CameraPos>().CameraPosition;
        Vector3 boatMinusPlr = transform.position - temp; ; //-----------------LIKELY THE ISSUE	
        float vecAngle = 0.0f;
        if (boatMinusPlr.y > 0.0f)
        {
            vecAngle = Mathf.Atan(boatMinusPlr.x / boatMinusPlr.y) + 1.57079632679f;//90 degrees
        }
        else
        {
            vecAngle = Mathf.Atan(boatMinusPlr.x / boatMinusPlr.y) + 4.71238898038f;//270 degrees
        }
        //Debug.Log(vecAngle);

        float boatMag = 0.0f;
        if ((ssX / 2.0f) / Mathf.Abs(Mathf.Cos(vecAngle)) <= (ssY / 2.0f) / Mathf.Abs(Mathf.Sin(vecAngle)))
        {
            boatMag = Mathf.Abs((boatMinusPlr.x / 2.0f) / Mathf.Abs(Mathf.Cos(vecAngle)));
        }
        else
        {
            boatMag = Mathf.Abs((boatMinusPlr.y / 2.0f) / Mathf.Abs(Mathf.Sin(vecAngle)));
        }
        //Debug.Log(boatMag);

        indicator.transform.position =
            new Vector3(
                -12f * Mathf.Cos(vecAngle),
                 12f * Mathf.Sin(vecAngle), 8) + temp;

        float d1 = Vector3.Magnitude(transform.position - temp);
        float d2 = Vector3.Magnitude(indicator.transform.position - temp);

        float dis = d1 - d2;
        dis = 1f / (0.1f*(dis + 1f));
        if (dis > 1f || dis < 0f)
        {
            indicator.SetActive(false);
        }
        else
        {
            indicator.SetActive(true);
            indicator.transform.localScale = new Vector3(dis, dis, 1);            
        }

        if (GameState.gameState == 1)
        {
            destroyLargeShip();
        }

        //Spawning
    }

    public void destroyLargeShip()
    {
        if (GameState.gameState == 0)
        {
            manager.GetComponent<ScoreingSystem>().score += (int)(300 * ScoreingSystem.mulitplier);
        }
        manager.GetComponent<EnemySpawning>().numberOfShips[2]--;
        Destroy(gameObject);
    }
    private void OnDestroy()
    {
        Destroy(indicator);  
    }
}