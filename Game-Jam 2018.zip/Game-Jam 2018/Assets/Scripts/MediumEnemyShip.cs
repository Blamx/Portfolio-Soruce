﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MediumEnemyShip : MonoBehaviour
{
    struct tile
    {
        public int x;
        public int y;
        public float score;
        public bool isIsland;
    }

    const float TAU = 6.2831853071f;

    public float shipMaxSpeed = 0.04f;
    public float shipMaxBackwardSpeed = -0.5f;
    public float shipSpeed = 0.0f;//-1 <-> 1
    public float shipAccel = 0.8f; //time to max in seconds

    public float shipAngle = 0.0f; //radians
    public float shipTurnSpeed = 0.12f; //rotations per second

    float orbitDistance = 14.0f;

    public GameObject steerTarget;
    public GameObject manager;

    public bool shootRight = true;
    public bool shooting = false;

    public int xTile, yTile;
    tile[] bestTiles = new tile[4];


    void Start()
    {
        manager = GameObject.Find("GameManager");
        steerTarget = GameObject.Find("Player");
        transform.position = new Vector3(transform.position.x, transform.position.y, 0.0f); //set start z to 0 so all same level

    }

    void Update()
    { 

        if (GameState.gameState == 0)
        {
            Vector3 newPosition = steerTarget.transform.position;
            float distBetweenObj = Vector3.Magnitude(transform.position - steerTarget.transform.position);

            if (orbitDistance < distBetweenObj)
            {
                xTile = Mathf.RoundToInt(gameObject.transform.position.x) / 10;
                yTile = Mathf.RoundToInt(gameObject.transform.position.y) / 10;

                int playerXTile = Mathf.RoundToInt(steerTarget.transform.position.x) / 10;
                int playerYTile = Mathf.RoundToInt(steerTarget.transform.position.y) / 10;

                Vector3[] possibleNextPos = { newPosition, newPosition, newPosition, newPosition };

                bestTiles[0].x = xTile; bestTiles[0].y = yTile - 1;
                bestTiles[1].x = xTile; bestTiles[1].y = yTile + 1;
                bestTiles[2].x = xTile + 1; bestTiles[2].y = yTile;
                bestTiles[3].x = xTile - 1; bestTiles[3].y = yTile;

                bestTiles[0].score = Vector2.Distance(new Vector2(bestTiles[0].x, bestTiles[0].y), new Vector2(playerXTile, playerYTile));
                bestTiles[1].score = Vector2.Distance(new Vector2(bestTiles[1].x, bestTiles[1].y), new Vector2(playerXTile, playerYTile));
                bestTiles[2].score = Vector2.Distance(new Vector2(bestTiles[2].x, bestTiles[2].y), new Vector2(playerXTile, playerYTile));
                bestTiles[3].score = Vector2.Distance(new Vector2(bestTiles[3].x, bestTiles[3].y), new Vector2(playerXTile, playerYTile));


                for (int k = 0; k < 4; k++)
                {
                    for (int l = 0; l < 4; l++)
                    {
                        if (bestTiles[k].score < bestTiles[l].score)
                        {
                            tile temp = bestTiles[l];
                            bestTiles[l] = bestTiles[k];
                            bestTiles[k] = temp;
                        }
                    }
                }

                for (int k = 0; k < manager.GetComponent<WaterSpawn>().waterTiles.Count; k++)
                {
                    int waterXTile = manager.GetComponent<WaterSpawn>().waterTiles[k].GetComponent<WaterStats>().slotX;
                    int waterYTile = manager.GetComponent<WaterSpawn>().waterTiles[k].GetComponent<WaterStats>().slotY;
                    bool isIsland = !manager.GetComponent<WaterSpawn>().waterTiles[k].GetComponent<WaterStats>().isIsland;

                    for (int l = 0; l < 4; l++)
                    {
                        if (waterXTile == bestTiles[l].x && waterYTile == bestTiles[l].y)
                        {
                            bestTiles[l].isIsland = isIsland;
                            possibleNextPos[l] = manager.GetComponent<WaterSpawn>().waterTiles[k].transform.position;
                            possibleNextPos[l].z = 0f;
                            break;
                        }
                    }
                }

                if (bestTiles[0].isIsland)
                {
                    newPosition = possibleNextPos[0];
                    Debug.DrawLine(transform.position, possibleNextPos[0]);
                }
                else if (bestTiles[1].isIsland)
                {
                    newPosition = possibleNextPos[1];
                    Debug.DrawLine(transform.position, possibleNextPos[1]);
                }
                else if (bestTiles[2].isIsland)
                {
                    newPosition = possibleNextPos[2];
                    Debug.DrawLine(transform.position, possibleNextPos[2]);
                }
                else if (bestTiles[3].isIsland)
                {
                    newPosition = possibleNextPos[3];
                    Debug.DrawLine(transform.position, possibleNextPos[3]);
                }
                //this.transform.position = Vector3.Lerp(this.transform.position, nextPos[0], Time.deltaTime / 5f);


                Vector3 objRelativePos = transform.InverseTransformPoint(newPosition);
                float angleBetwnForwards = Vector3.Angle(-transform.up, transform.position - newPosition);


                {
                    float turnVarFull = 108.0f;
                    float turnVarStop = 126.0f;

                    float shipTargetSpeed = 0.0f;

                    if (angleBetwnForwards >= turnVarStop)
                    {
                        shipTargetSpeed = 0.0f;
                    }
                    else if (angleBetwnForwards < turnVarStop && angleBetwnForwards > turnVarFull)
                    {
                        float lerpAmmt = (angleBetwnForwards - turnVarFull) / (turnVarStop - turnVarFull);
                        shipTargetSpeed = Mathf.Lerp(1, 0, lerpAmmt);
                    }
                    else if (angleBetwnForwards <= turnVarFull)
                    {
                        shipTargetSpeed = 1.0f;
                    }

                    if (shipSpeed > shipTargetSpeed)
                    {
                        shipSpeed -= shipAccel * Time.deltaTime;
                    }
                    else if (shipSpeed < shipTargetSpeed)
                    {
                        shipSpeed += shipAccel * Time.deltaTime;
                    }

                    //-------------------------
                    if (shipSpeed > 1.0f)
                    {
                        shipSpeed = 1.0f;
                    }
                    if (shipSpeed < shipMaxBackwardSpeed)
                    {
                        shipSpeed = shipMaxBackwardSpeed;
                    }
                }

                if (objRelativePos.x < 0.0f && angleBetwnForwards > 8.0f)
                {
                    shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                    shooting = false;
                }
                else if (objRelativePos.x > 0.0f && angleBetwnForwards > 8.0f)
                {
                    shipAngle += shipTurnSpeed * TAU * Time.deltaTime;
                    shooting = false;
                }
            }
            else
            {
                Vector3 objRelativePos = transform.InverseTransformPoint(steerTarget.transform.position);
                float angleBetwnForwards = Vector3.Angle(-transform.up, transform.position - steerTarget.transform.position);

                if (objRelativePos.x < 0.0f && angleBetwnForwards > 85.0f)
                {
                    shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                    shootRight = false;
                    shooting = true;
                }
                else if (objRelativePos.x < 0.0f && angleBetwnForwards < 95.0f)
                {
                    shipAngle += shipTurnSpeed * TAU * Time.deltaTime;
                    shootRight = false;
                    shooting = true;
                }
                else if (objRelativePos.x > 0.0f && angleBetwnForwards > 85.0f)
                {
                    shipAngle += shipTurnSpeed * TAU * Time.deltaTime;
                    shootRight = true;
                    shooting = true;
                }
                else if (objRelativePos.x > 0.0f && angleBetwnForwards < 95.0f)
                {
                    shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                    shootRight = true;
                    shooting = true;
                }
            }

            transform.position += new Vector3(
                   shipSpeed * shipMaxSpeed * Mathf.Sin(shipAngle),
                   shipSpeed * shipMaxSpeed * Mathf.Cos(shipAngle),
                   0);
            transform.rotation = Quaternion.Euler(
                0,
                0,
                -shipAngle * (360.0f / TAU));

        }
      
        if (GameState.gameState == 1)
        {
            destroyMediumShip();
        }
    }

    public void destroyMediumShip()
    {

        if (GameState.gameState == 0)
        {
            manager.GetComponent<ScoreingSystem>().score += (int)(75 * ScoreingSystem.mulitplier);
        }
        manager.GetComponent<EnemySpawning>().numberOfShips[0]--;
        Destroy(gameObject);
    }
}
