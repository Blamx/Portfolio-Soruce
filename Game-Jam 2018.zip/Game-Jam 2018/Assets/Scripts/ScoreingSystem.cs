﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class ScoreingSystem : MonoBehaviour {

    public Text scoreUI;
    public int score = 0;
    static public float mulitplier = 1;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
     
        mulitplier += Time.deltaTime/50; 
        if(GameState.gameState == 1)
        {
            //mulitplier = 1;
        }
        scoreUI.text = score.ToString();

    }
}
