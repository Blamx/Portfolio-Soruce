﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonBall : MonoBehaviour
{
    public float cannonBallDamage = 10.0f;

    public Vector3 dir;
    public float cannonBallSpeed = 0.2f;

    public float cannonBallLifetime = 3f;
    float timer;

    public bool PlayerShot;

    public GameObject Boom;

    public GameObject Splash;

    GameObject gameManager;

    // Use this for initialization
    void Start()
    {
        gameManager = GameObject.Find("GameManager");
        timer = 0.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (timer >= cannonBallLifetime)
        {
            destroyCannonBall();
        }
        timer += Time.deltaTime;

        transform.position += dir * cannonBallSpeed * Time.deltaTime;

        if (GameState.gameState == 1)
        {
            destroyCannonBall();
        }
    }

    public void destroyCannonBall()
    {
        if (timer < cannonBallLifetime)
        {
            if (gameManager.GetComponent<AudioManager>())
            {
                gameManager.GetComponent<AudioManager>().PlayAtPoint("Cannon Hit", transform.position, 3.0f);
            }
            if (GameState.gameState == 0)
            {
                Boom.transform.position =
                new Vector3(transform.position.x, transform.position.y, -1f);
                Instantiate<GameObject>(Boom);
            }
        }
        else
        {
            Splash.transform.position = transform.position;
            Instantiate<GameObject>(Splash);
        }
        Destroy(gameObject);
    }
}
