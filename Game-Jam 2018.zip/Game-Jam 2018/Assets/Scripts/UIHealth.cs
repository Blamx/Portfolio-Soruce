﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class UIHealth : MonoBehaviour {

    public Image maxHP;
    public Image currentHP;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        maxHP.rectTransform.sizeDelta = new Vector2(gameObject.GetComponent<PlayerStats>().maxHealth + 4, 25);
        currentHP.rectTransform.sizeDelta = new Vector2(gameObject.GetComponent<PlayerStats>().health, 20);
	}
}
