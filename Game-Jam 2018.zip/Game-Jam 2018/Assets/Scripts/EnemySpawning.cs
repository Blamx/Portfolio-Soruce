﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawning : MonoBehaviour
{
    public bool pause = false;
	public int numShips = 3;
	public GameObject[] ship     = new GameObject[16];
	public Vector2[] spawnRates  = new Vector2[16]; //min and max
    public float[] maxShips      = new float[16];
    public float[] numberOfShips = new float[16];
	float[] randSpawnTime = new float[16];
	float[] timer         = new float[16];

	public float spawnRadius;

	public GameObject spawnAround;

    bool increasedAlready = false;
    float roundNum = 0;

	void Start ()
	{
		for (int i = 0; i < numShips; i++)
		{
			timer[i] = 0.0f;
			randSpawnTime[i] = Random.Range(spawnRates[i].x, spawnRates[i].y);
		}
    }
	
	void Update ()
	{
        if (GameState.gameState == 0 && !pause)
        {
            increasedAlready = false;
            for (int i = 0; i < numShips; i++)
            {
                timer[i] += Time.deltaTime;
                if (timer[i] >= randSpawnTime[i] && numberOfShips[i] < (int)maxShips[i])
                {
                    numberOfShips[i]++;
                    GameObject gob = ship[i];
                    float angle = Random.Range(0, 6.2831853071f);
                    GameObject temp = Instantiate(gob);
                    temp.transform.position = spawnAround.transform.position + (new Vector3(Mathf.Sin(angle), Mathf.Cos(angle), 0.0f) * spawnRadius);
                    temp.GetComponent<PlayerStats>().maxHealth = gob.GetComponent<PlayerStats>().maxHealth * ScoreingSystem.mulitplier;
                    temp.GetComponent<PlayerStats>().health = gob.GetComponent<PlayerStats>().health * ScoreingSystem.mulitplier;
                    temp.GetComponent<PlayerStats>().maxSpeed = gob.GetComponent<PlayerStats>().maxSpeed * ScoreingSystem.mulitplier;
                    temp.GetComponent<PlayerStats>().damage = gob.GetComponent<PlayerStats>().damage * ScoreingSystem.mulitplier;
                    temp.GetComponent<PlayerStats>().fireRate = gob.GetComponent<PlayerStats>().fireRate / ScoreingSystem.mulitplier;
                    temp.GetComponent<PlayerStats>().accel = gob.GetComponent<PlayerStats>().accel * ScoreingSystem.mulitplier;
                    temp.GetComponent<PlayerStats>().angle = gob.GetComponent<PlayerStats>().angle * ScoreingSystem.mulitplier;


                    randSpawnTime[i] = Random.Range(spawnRates[i].x, spawnRates[i].y);
                    timer[i] = 0.0f;
                }
            }
        }
        else if (GameState.gameState == 1)
        {
            if (!increasedAlready)
            {
                for(int k = 0; k < numShips; k++)
                {
                    timer[k] = 0;
                }
                spawnRates[0].x -= spawnRates[0].x * 0.05f; spawnRates[0].y -= spawnRates[0].y * 0.005f;
                spawnRates[1].x -= spawnRates[1].x * 0.05f; spawnRates[1].y -= spawnRates[1].y * 0.005f;
                roundNum++;
                maxShips[0] += 2;
                maxShips[1] += 3;
                maxShips[2] += roundNum / 3f;
            }
            increasedAlready = true;
        }
	}
}
