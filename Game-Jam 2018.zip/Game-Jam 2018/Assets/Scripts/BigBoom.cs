﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBoom : MonoBehaviour {

	// Use this for initialization
	void Start ()
    {
        Destroy(gameObject,0.65f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
