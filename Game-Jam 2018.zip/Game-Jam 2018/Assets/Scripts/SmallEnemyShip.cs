﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmallEnemyShip : MonoBehaviour
{
    const float TAU = 6.2831853071f;

    public float shipMaxSpeed = 0.07f;
    public float shipMaxBackwardSpeed = -0.5f;
    public float shipSpeed = 0.0f;//-1 <-> 1
    public float shipAccel = 1.0f; //time to max in seconds

    public float shipAngle = 0.0f; //radians
    public float shipTurnSpeed = 0.166f; //rotations per second

    public float damage;

    public GameObject steerTarget;
    public GameObject manager;
    public GameObject explosion;

    struct tile
    {
        public int x;
        public int y;
        public float score;
        public bool isIsland;
    }

    public int xTile, yTile;
    tile[] bestTiles = new tile[4];
    void Start()
    {
        manager = GameObject.Find("GameManager");
        steerTarget = GameObject.Find("Player");
        transform.position = new Vector3(transform.position.x, transform.position.y, 0.0f); //set start z to 0 so all same level
    }

    void Update()
    {

        Vector3 newPosition = steerTarget.transform.position;

        if (GameState.gameState == 0)
        {          
            {
                float distBetweenObj = Vector3.Magnitude(transform.position - steerTarget.transform.position);

                if (distBetweenObj > 11)
                {
                    xTile = Mathf.RoundToInt(gameObject.transform.position.x) / 10;
                    yTile = Mathf.RoundToInt(gameObject.transform.position.y) / 10;

                    int playerXTile = Mathf.RoundToInt(steerTarget.transform.position.x) / 10;
                    int playerYTile = Mathf.RoundToInt(steerTarget.transform.position.y) / 10;

                    Vector3[] possibleNextPos = { newPosition, newPosition, newPosition, newPosition };

                    bestTiles[0].x = xTile; bestTiles[0].y = yTile - 1;
                    bestTiles[1].x = xTile; bestTiles[1].y = yTile + 1;
                    bestTiles[2].x = xTile + 1; bestTiles[2].y = yTile;
                    bestTiles[3].x = xTile - 1; bestTiles[3].y = yTile;


                    for (int k = 0; k < 4; k++)
                    {
                        bestTiles[k].score = Vector2.Distance(new Vector2(bestTiles[k].x, bestTiles[k].y), new Vector2(playerXTile, playerYTile));
                    }

                    for (int k = 0; k < 4; k++)
                    {
                        for (int l = 0; l < 4; l++)
                        {
                            if (bestTiles[k].score < bestTiles[l].score)
                            {
                                tile temp = bestTiles[l];
                                bestTiles[l] = bestTiles[k];
                                bestTiles[k] = temp;
                            }
                        }
                    }

                    for (int k = 0; k < manager.GetComponent<WaterSpawn>().waterTiles.Count; k++)
                    {
                        int waterXTile = manager.GetComponent<WaterSpawn>().waterTiles[k].GetComponent<WaterStats>().slotX;
                        int waterYTile = manager.GetComponent<WaterSpawn>().waterTiles[k].GetComponent<WaterStats>().slotY;
                        bool isIsland = !manager.GetComponent<WaterSpawn>().waterTiles[k].GetComponent<WaterStats>().isIsland;

                        for (int l = 0; l < 4; l++)
                        {
                            if (waterXTile == bestTiles[l].x && waterYTile == bestTiles[l].y)
                            {
                                bestTiles[l].isIsland = isIsland;
                                possibleNextPos[l] = manager.GetComponent<WaterSpawn>().waterTiles[k].transform.position;
                                possibleNextPos[l].z = 0f;
                                break;
                            }
                        }
                    }

                    if (bestTiles[0].isIsland)
                    {
                        newPosition = possibleNextPos[0];
                        Debug.DrawLine(transform.position, possibleNextPos[0]);
                    }
                    else if (bestTiles[1].isIsland)
                    {
                        newPosition = possibleNextPos[1];
                        Debug.DrawLine(transform.position, possibleNextPos[1]);
                    }
                    else if (bestTiles[2].isIsland)
                    {
                        newPosition = possibleNextPos[2];
                        Debug.DrawLine(transform.position, possibleNextPos[2]);
                    }
                    else if (bestTiles[3].isIsland)
                    {
                        newPosition = possibleNextPos[3];
                        Debug.DrawLine(transform.position, possibleNextPos[3]);
                    }
                }

                {
                    Vector3 objectRelativePos = transform.InverseTransformPoint(newPosition);
                    float angleBetweenForwards = Vector3.Angle(transform.up, transform.position - newPosition);


                    if (objectRelativePos.x < 0.0f && angleBetweenForwards > 5.0f)
                    {
                        shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                    }
                    else if (objectRelativePos.x > 0.0f && angleBetweenForwards > 5.0f)
                    {
                        shipAngle += shipTurnSpeed * TAU * Time.deltaTime;
                    }
                }

                //Ship Speed / forward & backward
                {
                    Debug.DrawRay(transform.position, transform.up * 1.2f, Color.red);
                    float angleBetweenForwards = 1.0f - (Vector3.Angle(transform.up, transform.position - steerTarget.transform.position) / 180.0f);


                    float turnVarFull = 0.2f;
                    float turnVarStop = 0.6f;

                    float shipTargetSpeed = 0.0f;

                    if (angleBetweenForwards >= turnVarStop)
                    {
                        shipTargetSpeed = 0.0f;
                    }
                    else if (angleBetweenForwards < turnVarStop && angleBetweenForwards > turnVarFull)
                    {
                        float lerpAmmt = (angleBetweenForwards - turnVarFull) / (turnVarStop - turnVarFull);
                        shipTargetSpeed = Mathf.Lerp(1, 0, lerpAmmt);
                    }
                    else if (angleBetweenForwards <= turnVarFull)
                    {
                        shipTargetSpeed = 1.0f;
                    }

                    if (shipSpeed > shipTargetSpeed)
                    {
                        shipSpeed -= shipAccel * Time.deltaTime;
                    }
                    else if (shipSpeed < shipTargetSpeed)
                    {
                        shipSpeed += shipAccel * Time.deltaTime;
                    }

                    //-------------------------
                    if (shipSpeed > 1.0f)
                    {
                        shipSpeed = 1.0f;
                    }
                    if (shipSpeed < shipMaxBackwardSpeed)
                    {
                        shipSpeed = shipMaxBackwardSpeed;
                    }

                }
            }

            transform.position += new Vector3(
                shipSpeed * shipMaxSpeed * Mathf.Sin(shipAngle),
                shipSpeed * shipMaxSpeed * Mathf.Cos(shipAngle),
                0);
            transform.rotation = Quaternion.Euler(
                0,
                0,
                -shipAngle * (360.0f / TAU));
        }

        if (GameState.gameState == 1)
        {
            destroySmallShip(false);
        }
    }

    public void destroySmallShip(bool wasSunk)
    {
        if (manager.GetComponent<ScoreingSystem>())
        {
            if (GameState.gameState == 0)
            {
                manager.GetComponent<ScoreingSystem>().score += (int)(25 * ScoreingSystem.mulitplier);
                if (!wasSunk)
                {
                    GameObject temp = Instantiate<GameObject>(explosion);
                    temp.transform.position = transform.position;
                    temp.transform.right = -transform.up;
                }
            }
        }
        manager.GetComponent<EnemySpawning>().numberOfShips[1]--;
        Destroy(gameObject);
    }
}
