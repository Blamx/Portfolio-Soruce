﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Menu : MonoBehaviour
{
    public PlayerStats player;
    public Text[] statTierText = new Text[5];
    public Text[] statUpgradeCostText = new Text[5];
    public Image[] statDisplays = new Image[5];
    public int damageUpgrades = 1, speedUpgrades = 1, turnUpgrades = 1, fireUpgrades = 1, healthUpgrades = 1;
    public ScoreingSystem score;
    public Sprite[] displays = new Sprite[4];

    public int BronzeTier = 5;
    public int SilverTier = 10;
    public int GoldTier   = 15;

    public float totalTier = 0;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        statTierText[0].text = speedUpgrades.ToString();
        statTierText[1].text = turnUpgrades.ToString();
        statTierText[2].text = damageUpgrades.ToString();
        statTierText[3].text = fireUpgrades.ToString();
        statTierText[4].text = healthUpgrades.ToString();

        statUpgradeCostText[0].text = (100 * (speedUpgrades + speedUpgrades)).ToString();
        statUpgradeCostText[1].text = (100 * (turnUpgrades + turnUpgrades)).ToString();
        statUpgradeCostText[2].text = (100 * (damageUpgrades + damageUpgrades)).ToString();
        statUpgradeCostText[3].text = (100 * (fireUpgrades + fireUpgrades)).ToString();
        statUpgradeCostText[4].text = (100 * (healthUpgrades + healthUpgrades)).ToString();

        totalTier = damageUpgrades + speedUpgrades + turnUpgrades + fireUpgrades + healthUpgrades;
    }
    public void addSpeed()
    {
        if (score.score >= 100 * (speedUpgrades + speedUpgrades))
        {
            score.score -= 100 * (speedUpgrades + speedUpgrades);
            player.maxSpeed += 10f;
            speedUpgrades++;
            checkUpgradeStat(0, speedUpgrades);
            if (speedUpgrades % 10f == 0)
            {
                player.maxSpeed += player.maxSpeed;
            }
        }
    }
    public void addTurn()
    {
        if (score.score >= 100 * (turnUpgrades + turnUpgrades))
        {
            score.score -= 100 * (turnUpgrades + turnUpgrades);
            player.turnSpeed += 0.1f;
            turnUpgrades++;
            checkUpgradeStat(1, turnUpgrades);
            if (turnUpgrades % 10f == 0)
            {
                player.turnSpeed += player.turnSpeed;
            }
        }
    }
    public void addDamage()
    {
        if (score.score >= 100 * (damageUpgrades + damageUpgrades))
        {
            score.score -= 100 * (damageUpgrades + damageUpgrades);
            player.damage += 10f;
            damageUpgrades++;
            checkUpgradeStat(2, damageUpgrades);
            if (damageUpgrades % 10f == 0)
            {
                player.damage += player.damage;
            }
        }
    }
    public void addFireRate()
    {
        if (score.score >= 100 * (fireUpgrades + fireUpgrades))
        {
            score.score -= 100 * (fireUpgrades + fireUpgrades);
            player.fireRate *= 0.95f;
            fireUpgrades++;
            checkUpgradeStat(3, fireUpgrades);
            if (fireUpgrades % 10f == 0)
            {
                player.fireRate *= 0.5f;
            }
        }
    }

    public void addHealth()
    {
        if (score.score >= 100 * (healthUpgrades + healthUpgrades))
        {
            score.score -= 100 * (healthUpgrades + healthUpgrades);
            player.maxHealth += 10.0f;
            healthUpgrades++;
            checkUpgradeStat(4, healthUpgrades);
            if (healthUpgrades % 10f == 0)
            {
                player.maxHealth += player.maxHealth;
            }
        }
    }

    void checkUpgradeStat(int statNum, int statTier)
    {
        if (statTier % 5f == 0)
        {
            if (statTier == BronzeTier)
            {
                statDisplays[statNum].sprite = displays[1];
                statDisplays[statNum].transform.localScale = new Vector3(1f, 0.8f, 1f);
            }
            else if (statTier == SilverTier)
            {
                statDisplays[statNum].sprite = displays[2];
            }
            else if (statTier == GoldTier)
            {
                statDisplays[statNum].sprite = displays[3];
            }
        }
    }
}
