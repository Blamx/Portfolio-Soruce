﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Audio;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public int numSounds = 4;
    public AudioClip[] sounds = new AudioClip[16];
    public string[] soundNames = new string[16];
    void Start()
    {
        PlayLooped("Ocean Waves", 0.1f);

    }

    void Update()
    {

    }

    public void PlayAtPoint(int index, Vector3 pos, float volume)
    {
        AudioSource.PlayClipAtPoint(sounds[index], pos, volume);
    }

    public void PlayAtPoint(string name, Vector3 pos, float volume)
    {
        int index = 0;
        for (int i = 0; i < numSounds; i++)
        {
            if (name == soundNames[i])
            {
                index = i;
            }
        }
        AudioSource.PlayClipAtPoint(sounds[index], pos, volume);
    }

    public void PlayLooped(int index, float volume)
    {
        GameObject audio = new GameObject();
        audio.AddComponent<AudioSource>();
        audio.GetComponent<AudioSource>().clip = sounds[index];
        audio.GetComponent<AudioSource>().loop = true;
        audio.GetComponent<AudioSource>().volume = volume;
        audio.GetComponent<AudioSource>().spatialBlend = 0.0f;//2d

        audio.GetComponent<AudioSource>().Play();
    }

    public void PlayLooped(string name, float volume)
    {
        int index = 0;
        for (int i = 0; i < numSounds; i++)
        {
            if (name == soundNames[i])
            {
                index = i;
            }
        }
        GameObject audio = new GameObject();
        audio.AddComponent<AudioSource>();
        audio.GetComponent<AudioSource>().clip = sounds[index];
        audio.GetComponent<AudioSource>().loop = true;
        audio.GetComponent<AudioSource>().volume = volume;
        audio.GetComponent<AudioSource>().spatialBlend = 0.0f;//2d

        audio.GetComponent<AudioSource>().Play();
    }
}
