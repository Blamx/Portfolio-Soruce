﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class GameState : MonoBehaviour
{

    public static int gameState = 0;
    public GameObject player;
    public GameObject menu;
    public Text waves;
    int rounds = 0;
    public bool start = false;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (gameState == 1)
            {
                Application.Quit();
            }
            else if (gameState == 0)
            {
                player.GetComponent<PlayerStats>().health = 0f;
            }
        }
        waves.text = rounds.ToString();
        if (!player.GetComponent<PlayerStats>().dead)
        {
            gameState = 0;
            menu.SetActive(false);
        }
        else if (player.GetComponent<PlayerStats>().dead)
        {
            gameState = 1;
        }
        if (gameState == 1)
        {
            ScoreingSystem.mulitplier = menu.GetComponent<Menu>().totalTier / 10;
            player.GetComponent<PlayerStats>().health = player.GetComponent<PlayerStats>().maxHealth;
            menu.SetActive(true);
            if (start)
            {
                start = false;
                menu.SetActive(false);
                rounds++;
                player.SetActive(true);
                player.GetComponent<PlayerStats>().health = player.GetComponent<PlayerStats>().maxHealth;
                player.GetComponent<PlayerStats>().dead = false;
                player.transform.position = new Vector3(0, 0, 0);
            }
        }

    }

    public void startGame()
    {
        start = true;
    }
}
