﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    // Gamepad DLL import
    [DllImport("ControllerInput")]
    public static extern void InitGamepads(); // Sets gamepad IDs (0 to 3)

    [DllImport("ControllerInput")]
    public static extern bool CheckGamepadConnected(int a_GamepadNum); // Checks gamepad state and updates input

    [DllImport("ControllerInput")]
    public static extern bool GetControllerKeyDown(int a_GamepadNum, int a_ButtonID); // Returns true if the button is pressed

    [DllImport("ControllerInput")]
    public static extern gamepadAxes GetControllerAxes(int a_GamepadNum);

    [DllImport("ControllerInput")]
    public static extern void SetControllerRumble(int a_GamepadNum, float a_LeftMotor, float a_RightMotor);

    // Returns true if button was pressed after last update
    [DllImport("ControllerInput")]
    public static extern bool GetControllerKeyPressed(int a_GamepadNum, int a_ButtonID);

    //Returns true if button was released after the last update
    [DllImport("ControllerInput")]
    public static extern bool GetControllerKeyReleased(int a_GamepadNum, int a_ButtonID);

    // Returns true if button is pressed
    [DllImport("ControllerInput")]
    public static extern bool GetCommandDown(int a_Player, string a_Command);

    // Returns true if command was pressed after last update
    [DllImport("ControllerInput")]
    public static extern bool GetCommandPressed(int a_Player, string a_Command);

    // Returns true if command was released after last update
    [DllImport("ControllerInput")]
    public static extern bool GetCommandReleased(int a_Player, string a_Command);

    [DllImport("ControllerInput")]
    public static extern void SetInputProfileDeadzones(string a_ProfileName, float a_ls, float a_rs, float a_lt, float a_rt);

    public struct gamepadAxes
    {

        public float l_ThumbStick_X;
        public float l_ThumbStick_Y;

        public float r_ThumbStick_X;
        public float r_ThumbStick_Y;

        public float l_Trigger;
        public float r_Trigger;
    };
    public enum button
    {
        A = 0,
        B = 1,
        X = 2,
        Y = 3,

        DPad_UP = 4,
        DPad_DOWN = 5,
        DPad_LEFT = 6,
        DPad_RIGHT = 7,

        Shldr_LEFT = 8,
        Shldr_RIGHT = 9,

        ThumbStick_LEFT = 10,
        ThumbStick_RIGHT = 11,

        Start = 12,
        Back = 13
    };

    // PlayerShoot vars
    public GameObject[] cannonBall = new GameObject[1];
    public float rTimer = 0;
    public float lTimer = 0;
    public bool isFiring = false;

    public int numCannons = 3;
    int lCannon = 0;
    int rCannon = 0;

    public GameObject cannonShoot;

    bool lshot = true, rshot = false;

    public GameObject[] cannons = new GameObject[6];

    // PlayerShip vars
    const float TAU = 6.2831853071f;

    public float shipMaxSpeed = 0.07f;
    public float shipMaxBackwardSpeed = -0.5f;
    public float shipDirection = 0; //-1 <-> 1
    public float shipAccel = 1.0f; //time to max in seconds

    public float shipAngle = 0.0f; //radians
    public float shipTurnSpeed = 0.166f; //rotations per second
   
    public GameObject gameManager;

    // Use this for initialization
    void Start()
    {
        InitGamepads();
        SetInputProfileDeadzones("default", 0.5f, 0.5f, 0.1f, 0.1f);

        // PlayerShoot
        cannons[0] = GameObject.Find("Plr Left Cannon 1");
        cannons[1] = GameObject.Find("Plr Left Cannon 2");
        cannons[2] = GameObject.Find("Plr Left Cannon 3");
        cannons[3] = GameObject.Find("Plr Right Cannon 1");
        cannons[4] = GameObject.Find("Plr Right Cannon 2");
        cannons[5] = GameObject.Find("Plr Right Cannon 3");
        // PlayerShip
        transform.position = new Vector3(transform.position.x, transform.position.y, 0.0f); //set start z to 0 so all same level
    }

    // Update is called once per frame
    void Update()
    {
        bool controllerConnected = CheckGamepadConnected(0);
        
        float rT = 0f;
        float lT = 0f;
        float tsL = 0f;
        float tsR = 0f;

        if (controllerConnected)
        {
            gamepadAxes axes = GetControllerAxes(0);
            rT = axes.r_Trigger;
            lT = axes.l_Trigger;

            tsL = axes.l_ThumbStick_Y;
            tsR = axes.r_ThumbStick_X;
        }

        // PlayerShoot
        {
            float fireRate = gameObject.GetComponent<PlayerStats>().fireRate;

            if ((Input.GetMouseButton(0) && Input.GetMouseButton(1)) ||
                (controllerConnected && lT > 0.1f && rT > 0.1f))
            {
                fireRate *= 2;
            }

            rTimer -= Time.deltaTime;
            lTimer -= Time.deltaTime;
            isFiring = false;

            if ((Input.GetMouseButton(0) || (lT > 0.1 && controllerConnected)) && lTimer < 0) //shoot left
            {
                isFiring = true;
                gameManager.GetComponent<AudioManager>().PlayAtPoint("Shoot", transform.position, 0.3f);
                GameObject gob = cannonBall[0];
                //gob.transform.position = transform.position + new Vector3(0, 0, 1);
                lCannon += 1;
                lCannon = lCannon % numCannons;
                gob.transform.position = cannons[lCannon].transform.position;
                gob.GetComponent<CannonBall>().dir = -transform.right;
                gob.GetComponent<CannonBall>().cannonBallDamage = gameObject.GetComponent<PlayerStats>().damage;

                Instantiate(gob);

                GameObject temp = Instantiate(cannonShoot);
                temp.transform.position = gob.transform.position + new Vector3(0, 0, 1);
                temp.transform.up = gob.GetComponent<CannonBall>().dir;
                lshot = false;
				

                lTimer = fireRate / numCannons;
            }
            if ((Input.GetMouseButton(1) || (rT > 0.1 && controllerConnected)) && rTimer < 0) //shoot right
            {
                isFiring = true;
                gameManager.GetComponent<AudioManager>().PlayAtPoint("Shoot", transform.position, 0.3f);
                GameObject gob = cannonBall[0];
                //gob.transform.position = transform.position + new Vector3(0, 0, 1);
                rCannon += 1;
                rCannon = rCannon % numCannons;
                gob.transform.position = cannons[rCannon + 3].transform.position;
                gob.GetComponent<CannonBall>().dir = transform.right;
                gob.GetComponent<CannonBall>().cannonBallDamage = gameObject.GetComponent<PlayerStats>().damage;
                Instantiate(gob);
                GameObject temp = Instantiate(cannonShoot);
                temp.transform.position = gob.transform.position + new Vector3(0, 0, 1);
                temp.transform.up = gob.GetComponent<CannonBall>().dir;
                rshot = false;
                
                rTimer = fireRate / numCannons;
            }
        }

        // PlayerShip
        {
            if (controllerConnected)
            {                
                shipAngle += shipTurnSpeed * TAU * Time.deltaTime * tsR;
                //shipSpeed += shipAccel * Time.deltaTime * tsL;
                gameObject.GetComponent<Rigidbody>().AddForce(shipMaxSpeed * Time.deltaTime * tsL * transform.up);
                shipDirection = tsL * 100f;
            }
            else
            {
                //Ship Steer / left & right
                {
                    if (Input.GetKey(KeyCode.A))
                    {
                        shipAngle -= shipTurnSpeed * TAU * Time.deltaTime;
                    }
                    if (Input.GetKey(KeyCode.D))
                    {
                        shipAngle += shipTurnSpeed * TAU * Time.deltaTime;
                    }
                }

                //Ship Speed / forward & backward
                {

                    if (Input.GetKey(KeyCode.W))
                    {
                        gameObject.GetComponent<Rigidbody>().AddForce(shipMaxSpeed * Time.deltaTime * 1 * transform.up);
                        shipDirection = 100;
                    }
                    else if (Input.GetKey(KeyCode.S))
                    {
                        gameObject.GetComponent<Rigidbody>().AddForce(shipMaxSpeed * Time.deltaTime * -1 * transform.up);
                        shipDirection = -100;
                    }
                    else
                    {
                        shipDirection = 0;
                    }

                }
            }

            //Debug.Log(Vector3.Magnitude(gameObject.GetComponent<Rigidbody>().velocity));

            //-------------------------

            /*transform.position += */
            /*gameObject.GetComponent<Rigidbody>().AddForce(new Vector3(
                 shipSpeed * shipMaxSpeed * Mathf.Sin(shipAngle),
                 shipSpeed * shipMaxSpeed * Mathf.Cos(shipAngle),
                 0)*100f);*/
            transform.rotation = Quaternion.Euler(
                0,
                0,
                -shipAngle * (360.0f / TAU));
        }
    }
}
