﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Target : MonoBehaviour
{

    public bool isPlayer;
    public PlayerStats player;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    private void OnTriggerEnter(Collider other)
    {

        if (other.GetComponent<CannonBall>())
        {
            if (!other.GetComponent<CannonBall>().PlayerShot && isPlayer)
            {
                player.health -= other.GetComponent<CannonBall>().cannonBallDamage;
                other.GetComponent<CannonBall>().destroyCannonBall();
            }
            if (other.GetComponent<CannonBall>().PlayerShot && !isPlayer)
            {
                player.health -= other.GetComponent<CannonBall>().cannonBallDamage;
                other.GetComponent<CannonBall>().destroyCannonBall();
            }
        }
        if (other.GetComponent<SmallEnemyShip>() && isPlayer)
        {
            player.health -= other.GetComponent<SmallEnemyShip>().damage;
            other.GetComponent<SmallEnemyShip>().destroySmallShip(false);
        }
    }
}
