﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ObjectBeat : MonoBehaviour
{

    [SerializeField]
    [Range(10, 500)]
    float BPM = 120;

    [SerializeField]
    AudioSource main;

    [SerializeField]
    AudioClip[] sounds = new AudioClip[0];

    [SerializeField]
    float timer = 0;
    bool downBeat = true;

    [SerializeField]
    float buffer = 1;

    bool hit = false;
    bool earlyHit = false;

    [System.Serializable]
    public struct beat
    {
        public float time;
        public int audioIndex;
    }

    [SerializeField]
    beat[] beats;

    [SerializeField]
    int currentBeat = 0;

   
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;

        if (timer < 0 && downBeat)
        {
            currentBeat++;
            if (currentBeat >= beats.Length)
            {
                currentBeat = 0;
            }
            main.PlayOneShot(sounds[beats[currentBeat].audioIndex]);
            timer += beats[currentBeat].time * (60/ (float)BPM);
            downBeat = !downBeat;
        }
        else if (timer < 0 && !downBeat)
        {

            currentBeat++;
            if (currentBeat >= beats.Length)
            {
                currentBeat = 0;
            }
            main.PlayOneShot(sounds[beats[currentBeat].audioIndex]);
            timer += beats[currentBeat].time * (60 / (float)BPM);
            downBeat = !downBeat;
        }
       
    }

    public float getBeatPos()
    {
        return timer / (beats[currentBeat].time * (60 / (float)BPM));
    }

    public bool getDownBeat()
    {
        return downBeat;
    }

    public int getBeat()
    {
        return currentBeat;
    }
}
