﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Beat : MonoBehaviour
{

    [SerializeField]
    [Range(10, 500)]
    float BPM = 120;

    [SerializeField]
    AudioSource main,feedback;

    [SerializeField]
    AudioClip[] sounds = new AudioClip[0];

    [SerializeField]
    float timer = 0;
    bool downBeat = true;

    [SerializeField]
    GameObject left, right, bar, rightBuffer, leftBuffer;


    [SerializeField]
    GameObject hitIndicator;

    GameObject target, lastTarget;

    [SerializeField]
    float buffer = 1;

    bool hit = false;
    bool earlyHit = false;

    [System.Serializable]
    public struct beat
    {
        public float time;
        public int audioIndex;
    }

    [SerializeField]
    beat[] beats;
    int currentBeat = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;

        leftBuffer.GetComponent<RectTransform>().sizeDelta = new Vector2(buffer, leftBuffer.GetComponent<RectTransform>().sizeDelta.y);
        rightBuffer.GetComponent<RectTransform>().sizeDelta = new Vector2(buffer, rightBuffer.GetComponent<RectTransform>().sizeDelta.y);

        if (timer < 0 && downBeat)
        {

            currentBeat++;
            if (currentBeat >= beats.Length)
            {
                currentBeat = 0;
            }

            main.PlayOneShot(sounds[beats[currentBeat].audioIndex]);
            timer += beats[currentBeat].time * (60/ (float)BPM);
            downBeat = !downBeat;
            target = left;
            lastTarget = right;

            if(hit)
            {
                feedback.PlayOneShot(sounds[2]);
                hit = false;
            }
        }
        else if (timer < 0 && !downBeat)
        {

            currentBeat++;
            if (currentBeat >= beats.Length)
            {
                currentBeat = 0;
            }
            main.PlayOneShot(sounds[beats[currentBeat].audioIndex]);
            timer += beats[currentBeat].time * (60 / (float)BPM);
            downBeat = !downBeat;
            target = right;
            lastTarget = left;
            if (hit)
            {
                feedback.PlayOneShot(sounds[2]);
                hit = false;
            }
        }
       
        if (bar.transform.position.x < (right.transform.position.x) - buffer && bar.transform.position.x > (left.transform.position.x) + buffer)
        {
            earlyHit = false;
        }


            bar.transform.position = Vector2.Lerp(lastTarget.transform.position,target.transform.position,timer /(beats[currentBeat].time * (60 / (float)BPM)));
    }

    public bool BuffCheck()
    {
        if (bar.transform.position.x > (right.transform.position.x) - buffer)
        {
            bar.GetComponent<Image>().color = Color.green;
            if (!downBeat)
            {
                hit = true;
                earlyHit = true;
            }
            else if (earlyHit == false)
            {
                feedback.PlayOneShot(sounds[2]);
            }
            return true;
        }
        else if (bar.transform.position.x < (left.transform.position.x) + buffer)
        {
            bar.GetComponent<Image>().color = Color.green;
            if (downBeat)
            {
                hit = true;
                earlyHit = true;
            }
            else if (earlyHit == false)
            {
                feedback.PlayOneShot(sounds[2]);
            }
            return true;
        }
        else
        {
            bar.GetComponent<Image>().color = Color.black;
            feedback.PlayOneShot(sounds[3]);
            return false;
        }

    }

    public void timeLand(float velUp)
    {
        //velUp; //velocity (in m/s) at start of jump
        float accGrav = -9.8f; //acceleration (in m/s^2) due to gravity

        float timeLand = velUp / (-0.5f * accGrav); //time object lands (in s)

        BPM = timeLand * 60;
    }

    public float getBeatPos()
    {
        return timer / (beats[currentBeat].time * (60 / (float)BPM));
    }

    public bool getDownBeat()
    {
        return downBeat;
    }
}
