﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Animations;

using Sirenix.OdinInspector;

public class PlayerMovement : MonoBehaviour
{

    [SerializeField, FoldoutGroup("PlayerStats")]
    float Speed = 1;

    [SerializeField, FoldoutGroup("PlayerStats")]
    float JumpPower = 10;

    Rigidbody rigidbody;

    [HideInInspector]
    public ParentConstraint parentConstraint;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
        parentConstraint = GetComponent<ParentConstraint>();
        //parentConstraint.constraintActive = true;
    }

    // Update is called once per frame
    void Update()
    {
        rigidbody.velocity += new Vector3(0, -9.8f, 0) * Time.deltaTime;

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
    }

    public void Jump()
    {
        rigidbody.AddForce(transform.up * JumpPower);
    }

    private void Move(Vector3 Direction)
    {
        rigidbody.velocity = Direction;
    }
}
