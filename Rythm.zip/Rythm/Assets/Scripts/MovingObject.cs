﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingObject : MonoBehaviour
{
    [SerializeField]
    ObjectBeat beat;

    [SerializeField]
    GameObject tar1, tar2, obj;


    [SerializeField]
    GameObject[] targets;

    [SerializeField]
    bool flipFlop = true;

    int currentTarget = 1;
    int oldTarget = 0;
    int oldBeat = 0;


    bool reverse = false;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {


        if (beat.getBeat() != oldBeat)
        {
            oldTarget = currentTarget;

            if (!reverse)
            {
                currentTarget++;
                if (currentTarget > targets.Length - 1)
                {
                    if (flipFlop)
                    {
                        reverse = true;
                        currentTarget -= 2;
                    }
                    else
                    {
                        currentTarget = 0;
                    }
                }
            }
            else if (reverse)
            {
                currentTarget--;
                if (currentTarget < 0)
                {
                    reverse = false;
                    currentTarget += 2;
                }
            }

            oldBeat = beat.getBeat();
        }


        obj.transform.localPosition = Vector3.Lerp(targets[currentTarget].transform.localPosition, targets[oldTarget].transform.localPosition, beat.getBeatPos());
        obj.transform.localRotation = Quaternion.Lerp(targets[currentTarget].transform.localRotation, targets[oldTarget].transform.localRotation, beat.getBeatPos());
        obj.transform.localScale = Vector3.Lerp(targets[currentTarget].transform.localScale, targets[oldTarget].transform.localScale, beat.getBeatPos());


    }

}

