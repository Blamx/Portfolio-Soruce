﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeatLight : MonoBehaviour
{

    [SerializeField]
    Light pointLight;

    [SerializeField]
    GameObject cube;

    Material mat;

    [SerializeField]
    ObjectBeat beat;

    [SerializeField]
    bool pulse, smooth;

    [SerializeField]
    float intenseity;

    // Start is called before the first frame update
    void Start()
    {
        mat = cube.GetComponent<MeshRenderer>().material;
    }

    // Update is called once per frame
    void Update()
    {
        if (pulse)
        {
            pointLight.intensity = beat.getBeatPos() * intenseity;
            mat.SetColor("_EmissionColor", new Color(0.0f, 0.7f, 1.0f, 1.0f) * (beat.getBeatPos() * intenseity));
        }

        if(smooth)
        {
            float t = Mathf.Abs(beat.getBeatPos() - 0.5f) * 2;

            pointLight.intensity = t * intenseity;
            mat.SetColor("_EmissionColor", new Color(0.0f, 0.7f, 1.0f, 1.0f) * (t * intenseity));
        }
    }
}
