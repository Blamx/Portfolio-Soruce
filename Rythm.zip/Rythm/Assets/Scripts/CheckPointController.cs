﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPointController : MonoBehaviour
{
   
    GameObject[] checkPoints;

    [SerializeField]
    GameObject player;

    int current = 0;

    // Start is called before the first frame update
    void Start()
    {
        init();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetCheckpoint(int _id)
    {
        for (int i = 0; i < checkPoints.Length; i++)
        {
            checkPoints[i].GetComponent<CheckPoint>().current = false;
        }

        checkPoints[_id].GetComponent<CheckPoint>().current = true;
        current = _id;
    }
    void init()
    {
        checkPoints = GameObject.FindGameObjectsWithTag("CheckPoint");

        for (int i = 0; i < checkPoints.Length; i++)
        {
            checkPoints[i].GetComponent<CheckPoint>().id = i;
        }
    }

    public void respawn()
    {
        player.transform.position = checkPoints[current].transform.position;
        player.transform.rotation = checkPoints[current].transform.rotation;
        player.GetComponent<Rigidbody>().velocity = Vector3.zero;
    }
}
