﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Sirenix.OdinInspector;

public class Control : MonoBehaviour
{
    [SerializeField]
    float buffed = 2.0f, debuffed = 0.5f;

   

    [SerializeField]
    Rigidbody rb;

    [SerializeField, FoldoutGroup("PlayerStats")]
    float baseSpeed = 1;
    [SerializeField, FoldoutGroup("PlayerStats")]
    float basejump = 10;
    float dashMod = 1;

    float speed = 1;
    float jump = 20;

    [SerializeField]
    Camera cam;

    [SerializeField]
    public GameObject dummyPlayer;

    public bool onFloor = false;
    public bool snap = false;

    [SerializeField]
    Vector3 playerScale = new Vector3(1, 1, 1);

    Ray norm = new Ray(Vector3.zero, Vector3.zero);
    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        //transform.rotation = dummyPlayer.transform.rotation;
        //transform.position = dummyPlayer.transform.position;

        Debug.DrawRay(norm.origin, norm.direction);

        Debug.DrawLine(transform.position, (transform.position + transform.forward * 2), Color.blue);
        Debug.DrawLine(transform.position, (transform.position + transform.up * 2), Color.green);
        Debug.DrawLine(transform.position, (transform.position + transform.right * 2), Color.red);

        Debug.DrawLine(cam.transform.position, (cam.transform.position + cam.transform.forward * 10), Color.blue);
        Debug.DrawLine(cam.transform.position, (cam.transform.position + cam.transform.up * 10), Color.green);
        Debug.DrawLine(cam.transform.position, (cam.transform.position + cam.transform.right * 10), Color.red);

        if (Input.GetKeyDown(KeyCode.W))
        {
                speed = baseSpeed;
        }
        if (Input.GetKeyDown(KeyCode.S))
        {      
                speed = baseSpeed;
        }
        if (Input.GetKeyDown(KeyCode.A))
        {

                speed = baseSpeed;
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
                speed = baseSpeed;
        }


        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.forward * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.position -= transform.forward * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.position -= transform.right * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.position += transform.right * speed * Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Space) && onFloor)
        {
                jump = basejump;
          
            rb.AddForce(transform.up * jump, ForceMode.Impulse);
        }

        transform.Rotate(transform.up, Input.GetAxis("Mouse X"), Space.World);

        //transform.localEulerAngles += new Vector3(0, Input.GetAxis("Mouse X"), 0);
        cam.transform.localEulerAngles += new Vector3(-Input.GetAxis("Mouse Y"), 0, 0);

        if (onFloor)
        {
            RaycastHit rayHit;
            norm = new Ray(transform.position, -transform.up);
            if (snap && Physics.Raycast(transform.position, -transform.up, out rayHit, 5.0f))
            {
                Vector3 rot = transform.forward;
                transform.up = rayHit.normal;
                if (Vector3.Angle(transform.right, rot) > 90)
                    transform.Rotate(transform.up, -Vector3.Angle(transform.forward, rot), Space.World);
                else
                    transform.Rotate(transform.up, Vector3.Angle(transform.forward, rot), Space.World);



                snap = false;
            }

        }
        //gravity
        rb.AddForce(-transform.up * 9.8f, ForceMode.Acceleration);

        onFloor = false;


    }
}
