﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPoint : MonoBehaviour
{
    public bool current = false;
    public int id = 0;

    [SerializeField]
    bool finish = false;

    [SerializeField]
    GameObject finsihText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            GetComponentInParent<CheckPointController>().SetCheckpoint(id);
            if(finish)
            {
                finsihText.SetActive(true);
            }
        }
    }
}
