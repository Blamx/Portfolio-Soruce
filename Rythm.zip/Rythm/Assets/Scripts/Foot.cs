﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Foot : MonoBehaviour
{
    [SerializeField]
    Control con;
    [SerializeField]
    GameObject player;

    GameObject par;
    // Start is called before the first frame update
    void Start()
    {
        par = player.transform.parent.gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Floor")
        {
            con.onFloor = true;
            //par.transform.rotation = player.transform.rotation;
            par.transform.parent = other.transform.parent;
            //par.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            player.transform.parent = par.transform;
            con.snap = true;
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if(other.tag == "Floor")
        {
            par.transform.parent = other.transform.parent;
            player.transform.parent = par.transform;
            con.onFloor = true;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Floor")
        {
            player.transform.parent = null;
            par.transform.parent = null;
            con.onFloor = false;
        }
    }

}
